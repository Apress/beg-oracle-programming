 select abs(13.4)
    from dual
  /

 select abs(-4.5)
    from dual
  /

 select abs(-70 * 415) "Using an expression"
    from dual
  /
