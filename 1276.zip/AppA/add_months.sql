 select add_months( sysdate, 12 ) "Next Year"
    from dual
  /

 select add_months( sysdate, -12 ) "Last Year"
    from dual
  /
