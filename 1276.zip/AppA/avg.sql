 select avg( sal )
    from emp
  /
