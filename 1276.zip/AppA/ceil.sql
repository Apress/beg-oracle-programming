 select ceil( 10.00000000001 )  
    from dual;

 select ceil( -1.99 )        
    from dual
  /
