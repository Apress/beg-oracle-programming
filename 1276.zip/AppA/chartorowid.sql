 select empno, ename, job, hiredate
    from emp
   where rowid = chartorowid('AAAH14AABAAAO+HAAI')
  /
