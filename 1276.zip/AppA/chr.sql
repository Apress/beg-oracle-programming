 select chr(71)||chr(114)||chr(111)||chr(111)||chr(118)||chr(121) "Cool!"
    from dual
  /
