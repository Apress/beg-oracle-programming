 select coalesce( null, '', 'A' )
    from dual
  /

 select coalesce( null, sysdate )
    from dual
  /

