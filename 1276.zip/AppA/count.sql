 select count( * )
    from emp
  /

 select empno, ename
    from emp
   where mgr is null
  /

 select count( mgr )
    from emp
  /
