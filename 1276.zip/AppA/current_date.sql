 column sessiontimezone for a15
 select sessiontimezone, current_date
    from dual
  /

 alter session set time_zone = '-08:00'
  /

 select sessiontimezone, current_date
    from dual
  /
