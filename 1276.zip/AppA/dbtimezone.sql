 select DBTIMEZONE
    from dual
  /
