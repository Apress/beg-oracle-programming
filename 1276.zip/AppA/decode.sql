 select dname, decode( loc, 'BOSTON', 'Red Sox fans',
                             'CHICAGO', 'White Sox fans',
                             'DALLAS', 'Astros fans',
                             'NEW YORK', 'Mets fans' ) "Baseball Team"
    from dept
  /


 select decode( ename, 'KING', 'KING OF THE HILL', ename ) "ENAME"
    from emp
  /
