 select dump( ename, 8 )
    from emp
  /

 select dump( ename, 16 )
    from emp
  /
