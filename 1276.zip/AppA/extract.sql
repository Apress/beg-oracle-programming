 select extract( month from sysdate ) "This Month"
    from dual
  /

 select extract( year from add_months(sysdate,36) ) "3 Years Out"
    from dual
  /
