 select greatest( 'A', 'a' )
    from dual
  /

 select greatest( 'ONE', 1 )
    from dual
  /

 select greatest( 1, 5, 10 )
    from dual
  /
