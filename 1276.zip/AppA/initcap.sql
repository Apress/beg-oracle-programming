 select initcap('THESE WORDS will be INITcapped')
    from dual
  /

 select initcap( table_name )
    from user_tables
  /
