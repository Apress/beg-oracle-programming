 select last_day( date'2000-02-01' ) "Leap Yr?"
    from dual
  /

 select last_day( sysdate ) "Last day of this month"
    from dual
  /
