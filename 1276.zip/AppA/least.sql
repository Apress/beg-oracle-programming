 select least( 'X', 'x' )
    from dual
  /

 select least( 'A', 'B', 'C' )
    from dual
  /
