 select ename, length( ename )
    from emp
  /
