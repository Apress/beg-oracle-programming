 select lower( table_name )
    from user_tables
  /
