 select '"' || ltrim( '    Some String' ) || '"' "A String"
    from dual
  /
