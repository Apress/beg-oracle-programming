 select max( sal )
    from emp
  /

