 select min( sal )
    from emp
  /
