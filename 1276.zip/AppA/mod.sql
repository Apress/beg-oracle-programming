 select mod( 11,2 )
    from dual
  /

 select mod( 150.12, 2.6 )
    from dual
  /
