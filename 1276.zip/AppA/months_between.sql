 select months_between( sysdate, date'1971-05-18' )
    from dual
  /

 select months_between( sysdate, date'2001-01-01' )
    from dual
  /
