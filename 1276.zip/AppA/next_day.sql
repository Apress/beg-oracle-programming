 select next_day( date'2001-09-11', 'SUNDAY' )
    from dual
  /

 select next_day( date'2002-01-01', 'FRI' )
    from dual
  /
