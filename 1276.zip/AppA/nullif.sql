 select nullif( 1, 1 )
    from dual
  /

 select nullif( 1, null )
    from dual
  /
