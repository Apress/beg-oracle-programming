 column current_timestamp format a38
 select current_timestamp
    from dual
  /

 select current_timestamp + numtodsinterval( 2, 'hour' ) current_timestamp
    from dual
  /
