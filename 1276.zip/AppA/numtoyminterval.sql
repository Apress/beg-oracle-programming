 select current_timestamp
    from dual
  /

 select current_timestamp + numtoyminterval( 3, 'month' ) current_timestamp
    from dual
  /
