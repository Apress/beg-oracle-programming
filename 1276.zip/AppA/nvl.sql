 select nvl( '', 'Yes '''' is null' ) "Evaluate"
    from dual
  /

 select e.ename, nvl( e2.ename, 'NO BOSS! PARTY TIME!' ) "MGR"
    from emp e, emp e2
   where e.mgr = e2.empno(+)
  /
