 select e.ename, nvl2( e2.ename, 'BACK TO WORK!', 'NO BOSS!' ) "MGR"
    from emp e, emp e2
   where e.mgr = e2.empno(+)
  /
