 select power( 10, 5 )
    from dual
  /

 select power( -5, 3 ) "Using Negatives"
    from dual
  /

 select power( 5.2, 2.7 ) "With Reals"
    from dual
  /
