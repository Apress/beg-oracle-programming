 select replace( 'Oracle is great!', 'great', 'awesome' )
    from dual
  /
