 select round( sysdate )
    from dual
  /

 select round( sysdate, 'year' )
    from dual
  /

 select round( sysdate, 'month' )
    from dual
  /

 select round( sysdate, 'q' ) "Quarter"
    from dual
  /
