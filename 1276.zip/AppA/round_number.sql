 select round( 12345.67890 )
    from dual
  /

 select round( 12345.67890, 2 )
    from dual
  /

 select round( 12345.67890, -2 )
    from dual
  /
 