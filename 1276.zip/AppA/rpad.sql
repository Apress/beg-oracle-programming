 select rpad( '*', 5, '*' )
    from dual
  /

 select rpad( ename, 10, ' ' ) || '(' || job || ')' "Responsibilities"
    from emp
   order by ename
  /
