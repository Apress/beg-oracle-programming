 select '"' || rtrim( 'Some String     ' ) || '"' "A String"
    from dual
  /
