 select sign( 123 )
    from dual
  /

 select sign( 100 � ( 50 * 2 ) ) "Using expressions"
    from dual
  /

 select sign( 123 * -1 + 122) "Using expressions"
    from dual
  /
