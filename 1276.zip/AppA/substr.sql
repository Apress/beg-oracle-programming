 select substr( '1234567890', 5 )
    from dual
  /
