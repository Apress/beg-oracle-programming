 select sum( sal )
    from emp
  /
