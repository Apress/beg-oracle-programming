 select sysdate
    from dual
  /

 select to_char(sysdate,'DD-MON-YY HH24:MI:SS' ) "Right Now"
    from dual
  /

