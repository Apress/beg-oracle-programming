 select systimestamp
    from dual
  /
