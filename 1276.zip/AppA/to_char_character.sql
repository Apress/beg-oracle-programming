 create table xmldata(
    xmldoc clob )
  /

 insert into xmldata
  select dbms_xmlquery.getxml('select * from emp')
    from dual
  /

 select to_char( xmldoc )
    from xmldata
  /
