 select to_char( sysdate, 'DD/MM/YY HH24:MI:SS' ) "Right Now"
    from dual
  /

 select to_char( hiredate, 'Day Mon, YYYY' )
    from emp
   where empno = 7839
  /
