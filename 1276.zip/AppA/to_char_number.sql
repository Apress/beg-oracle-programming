 select ename, to_char( sal, '$9,999.99' ) "Salary"
    from emp
  /
