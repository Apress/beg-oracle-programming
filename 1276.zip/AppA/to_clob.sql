 create table xmldata(
    xmldoc clob )
  /

 insert into xmldata values
  ( to_clob( '<?xml version="1.0"?>
  <ROWSET>
     <ROW num="1">
        <EMPNO>7369</EMPNO>
        <ENAME>SMITH</ENAME>
        <JOB>CLERK</JOB>
        <MGR>7902</MGR>
        <HIREDATE>12/17/1980 0:0:0</HIREDATE>
        <SAL>800</SAL>
        <DEPTNO>20</DEPTNO>
     </ROW>
  </ROWSET>' ) )
  /
