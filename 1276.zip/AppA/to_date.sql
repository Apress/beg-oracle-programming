 create table author_log(
    activity clob,
    completed date
  )
  /


 insert into author_log values (
    'Began SQL Functions appendix', 
    to_date( '04-NOV-2001 08:00', 'DD-MON-YYYY HH24:MI' )
  )
  /
