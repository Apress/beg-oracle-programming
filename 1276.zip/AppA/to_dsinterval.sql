 alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';

 select sysdate
    from dual
  /


 select sysdate - to_dsinterval( '1 00:00:00' ) "US Marines Birthday"
    from dual
  /
