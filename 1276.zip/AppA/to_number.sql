 select to_number( '15' )
    from dual
  /
