 select to_timestamp( '2001-NOV-11 08:00:00', 'YYYY-MON-DD HH:MI:SS' )
    from dual
  /
