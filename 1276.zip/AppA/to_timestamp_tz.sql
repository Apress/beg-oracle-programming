 select to_timestamp_tz('2001-NOV-11 08:00:00 -05:00',
                         'YYYY-MON-DD HH:MI:SS TZH:TZM') "TS w/ TZ"
    from dual
  /
