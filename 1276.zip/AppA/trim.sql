 select '"' || trim( ' ' from '   This is a string    ' ) || '"' "Result"
    from dual
  /

 select trim( trailing ' ' from 'This is a string     ' ) "Result"
    from dual
  /
