 select trunc( sysdate )
    from dual
  /

 select to_char( trunc( sysdate, 'HH' ), 
                  'DD-MON-YY HH24:MI:SS' ) "The Current Hour"
    from dual
  /
