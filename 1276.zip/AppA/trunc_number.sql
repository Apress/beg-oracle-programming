 select trunc( 12345.67890 )
    from dual
  /

 select trunc( 12345.67890, 2 )
    from dual
  /

 select trunc( 12345.67890, -2 )
    from dual
  /
