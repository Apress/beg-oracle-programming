 select uid "Current UID"
    from dual
  /
