 connect hr/hr
 select department_name, upper( department_name )
    from departments
   where rownum < 11
   order by department_name
  /
