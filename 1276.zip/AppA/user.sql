 select user Current_User
    from dual
  /

 select object_name, object_type
    from all_objects
   where owner = user
  /
