begin
      for i in 1 .. 10 loop
        dbms_output.put_line( dbms_random.normal );
      end loop;
    end;
    /