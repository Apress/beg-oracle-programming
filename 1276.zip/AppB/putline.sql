exec dbms_output.put_line( dbms_random.string( 'A', 20 ) );
     exec dbms_output.put_line( dbms_random.string( 'x', 20 ) );
     exec dbms_output.put_line( dbms_random.string( 'P', 20 ) );
     exec dbms_output.put_line( dbms_random.string( 'l', 20 ) );
     exec dbms_output.put_line( dbms_random.string( 'u', 20 ) );
