
 set serverout on
 exec dbms_output.put_line( dbms_random.value );

 set serverout on
 exec dbms_output.put_line( dbms_random.value );


 set serverout on
 exec dbms_random.seed( to_char( sysdate, 'YYYYMMDD' ) );
     exec dbms_output.put_line( dbms_random.value );
     exec dbms_output.put_line( dbms_random.value );


 set serverout on
 exec dbms_random.seed( to_char( sysdate, 'YYYYMMDD' ) );
     exec dbms_output.put_line( dbms_random.value );
     exec dbms_output.put_line( dbms_random.value );