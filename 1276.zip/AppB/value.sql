begin
      for i in 1 .. 10 loop
        dbms_output.put_line( round( dbms_random.value*100 ) );
      end loop;
    end;
    /
 begin
      for i in 1 .. 10 loop
        dbms_output.put_line( trunc( dbms_random.value( 1, 101 ) ) );
      end loop;
    end;
    /