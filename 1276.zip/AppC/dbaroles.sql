select role, password_required 
      from dba_roles
     order by role
    /