 select parameter, value 
    from v$option
   order by parameter
  /
