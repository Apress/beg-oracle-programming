grant execute on debug to public;


