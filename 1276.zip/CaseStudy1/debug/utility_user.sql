create user utility identified by utility;

grant connect, resource, create public synonym to utility;



