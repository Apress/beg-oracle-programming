-- Run from a DBA account

@debug\utility_user.sql

connect utility/utility;

@debug\debugtab.sql

@debug\debug_def.sql

@debug\biu_fer_debugtab.sql

@debug\debug_body.sql

@debug\public_debug.sql

