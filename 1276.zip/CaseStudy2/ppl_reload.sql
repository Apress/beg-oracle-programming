@ppl_popul.sql
@ppl_load.sql
exit
