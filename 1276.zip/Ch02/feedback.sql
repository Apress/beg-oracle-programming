set pagesize 1000                       
 show feedback

 select empno, ename, job
      from emp
     where rownum < 7
    /

set feedback off
     select empno, ename, job
      from emp
     where rownum < 7
    /
set feedback 3
 select empno, ename, job
      from emp
     where rownum < 3
    /
select empno, ename, job
      from emp
     where rownum < 4
    /