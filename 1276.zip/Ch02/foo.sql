select a
      from foo;