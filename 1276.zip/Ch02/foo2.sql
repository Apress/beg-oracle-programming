begin
      for cur1 in (select a
                     from foo) loop
        dbms_output.put_line(cur1.a || ' is a value in FOO');
      end loop;
    end;
    /