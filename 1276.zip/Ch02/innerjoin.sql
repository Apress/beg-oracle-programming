select e.employee_id, e.last_name, d.department_name
      from employees e inner join departments d
        on e.department_id = d.department_id
     where e.job_id = 'SA_MAN'
    /
insert into employees
    (employee_id, last_name, email, hire_date, job_id, department_id)
    values
    (99999, 'Doe', 'john@doe.com', '01-JAN-2002', 'SA_MAN', null);
 select e.employee_id, e.last_name, d.department_name
      from employees e inner join departments d
        on e.department_id = d.department_id
     where e.job_id = 'SA_MAN'
    /
