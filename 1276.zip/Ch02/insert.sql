insert into jobs (job_id, job_title, min_salary, max_salary)
    values ('IT_DBA', 'Database Administrator', 4000.00, 10000.00) 
    /
insert into jobs (job_id, job_title, min_salary)
    values ('IT_AUTHOR', 'Technical Author', 5000.00)
    /
select job_id, job_title
      from jobs
    /
