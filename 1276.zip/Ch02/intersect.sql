select employee_id, last_name
      from employees
     where last_name like 'A%'
        or last_name like 'B%'
    intersect
    select employee_id, last_name
      from employees
     where last_name like 'B%'
        or last_name like 'C%'
   /