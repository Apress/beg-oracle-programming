select employee_id, last_name
      from employees
     where department_id in (20, 110);
select employees.employee_id, employees.last_name,
           departments.department_name
      from employees, departments
     where employees.department_id in (20, 110)
       and departments.department_id in (20, 110)
    /
select employees.employee_id, employees.last_name,
           departments.department_name
      from employees, departments
     where employees.department_id in (20, 110)
       and departments.department_id = employees.department_id
    /
