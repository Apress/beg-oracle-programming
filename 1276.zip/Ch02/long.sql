select text
      from all_views
     where view_name = 'USER_TABLES';
set pagesize 1000
set long 10000
 /