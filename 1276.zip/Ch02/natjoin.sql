select employee_id, last_name, department_name
      from employees natural join departments
     where department_name = 'Purchasing'
    /
