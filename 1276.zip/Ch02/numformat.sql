create table t( my_column number );

 insert into t values ( 1234567890 );
 insert into t values ( 12345678901 );
 insert into t values ( 12345678901234567890 );

select *      
      from t;

set numformat 99999999999999999999.99999999999999
 /

set numformat ""
 /

 