select last_name, salary
      from employees
     where salary > 12000
     order by salary
    /
select last_name, salary
      from employees
     where salary > 12000
     order by salary desc
    /