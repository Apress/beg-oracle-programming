select e.employee_id, e.last_name, d.department_name
      from employees e left outer join departments d
        on e.department_id = d.department_id
     where e.job_id = 'SA_MAN'
    /
select e.employee_id, e.last_name, d.department_name
      from employees e right outer join departments d
        on e.department_id = d.department_id
     where d.location_id = 1700
     order by d.department_name, e.last_name
    /
select e.employee_id, e.last_name, d.department_name
      from employees e, departments d
     where e.department_id = d.department_id(+)
       and e.job_id = 'SA_MAN'