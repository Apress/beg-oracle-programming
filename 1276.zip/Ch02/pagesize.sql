set pagesize 10
 select rownum, object_name
      from all_objects
     where rownum < 20
    /