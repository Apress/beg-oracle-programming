delete
      from employees
     where department_id = 1234;
select employee_id, last_name, email
      from employees
     where last_name = 'Lawson'
    /
rollback;
select employee_id, last_name, email
      from employees
     where last_name = 'Lawson'
    /