SQL> select *  
      from emp;