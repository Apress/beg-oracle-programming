select e.employee_id, e.last_name, d.department_name
      from employees e, departments d
     where d.department_name in ('Accounting','Marketing')
       and e.department_id = d.department_id
    /

select e.employee_id, e.last_name, department_name
      from employees e, departments
     where department_name in ('Accounting','Marketing')
       and e.department_id = department_id
    /
select employee_id "Emp #", last_name Last,
           department_name AS "Department"
      from employees e, departments d
     where d.department_id = e.department_id
       and d.department_id = 30
    /