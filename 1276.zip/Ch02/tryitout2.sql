describe dept
select *        
      from dept
    /
