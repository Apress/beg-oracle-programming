desc dept
select deptno, dname
      from dept;
