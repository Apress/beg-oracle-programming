select last_name, job_id, salary
      from employees
     where salary > 12000
     order by job_id, salary
    /