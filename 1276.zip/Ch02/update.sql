select job_id, last_name, salary
      from employees
     where job_id in ('IT_PROG', 'ST_CLERK')
     order by job_id, last_name
    /
 update employees
       set salary = salary * 1.15
     where job_id = 'IT_PROG'
    /
select job_id, last_name, salary
      from employees
     where job_id in ('IT_PROG', 'ST_CLERK')
     order by job_id, last_name
    /