select empno, ename
      from emp
     where ename like 'A%';
select empno, ename, sal, comm
      from emp
     where deptno = 30
       and comm > 0
    /
select empno, ename, deptno, sal, comm
      from emp
     where sal >= 3000
        or comm >= 500
    /
