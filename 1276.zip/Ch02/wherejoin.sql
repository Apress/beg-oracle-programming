select jobs.job_title, employees.last_name, salary
      from jobs, employees
     where jobs.job_id = employees.job_id
       and employees.salary > 10000
    /
