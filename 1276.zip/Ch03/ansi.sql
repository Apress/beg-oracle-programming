create table foo (
      a   integer,
      b   dec( 9, 2 ),
      c   character varying( 30 ),
      d   national char( 3 )
    )
    /
describe foo
