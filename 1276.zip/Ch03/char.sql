create table authorized_blends(
      bean_name char(50)
    );
 insert into authorized_blends values( 'Papua New Guinea' );
 insert into authorized_blends values( 'Ethiopia' );
 insert into authorized_blends values( 'Sumatra' );
SQL> select bean_name, length( bean_name )
      from authorized_blends 
    /
