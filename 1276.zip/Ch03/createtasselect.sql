create table emp_copy as
    select *
      from scott.emp
     where 1 = 0
    /

 select * 
      from emp_copy
    /