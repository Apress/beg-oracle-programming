create user hr_audit
    identified by hr_audit
    /
    grant create session, resource
    to hr_audit
alter user hr_audit 
     identified by oracle;