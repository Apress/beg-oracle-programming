create table authorized_blends(
      bean_name char(50 char)
    );