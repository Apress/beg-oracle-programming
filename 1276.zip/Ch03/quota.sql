create table retired_employees(
      employee_id number,
      last_name   varchar2(30)
    )
    /
alter user hr_audit
    quota unlimited on users
    quota 10M on temp
    quota 0M on system
    /