grant select on dept to hr_audit;
create table another_dept
    as select *
         from scott.dept;
 select *
      from another_dept;
    /
 insert into another_dept
    values (40, 'OPERATIONS', 'BOSTON');
     select *
      from another_dept;
insert into another_dept (loc) 
    values ('RESTON')
    /
select * from another_dept;