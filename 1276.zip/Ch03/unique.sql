SQL> alter table another_emp
    add (
      ssn varchar2( 9 )
    );
     alter table another_emp
    add constraint another_emp_ssn_uk
    unique( ssn );
SQL> update another_emp set ssn='123456789';

