grant all on directory ext_data_files to scott
/