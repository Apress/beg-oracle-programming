 create table drop_me
     a   int,
     b   int
   )
   /

   insert into drop_me
    values ( 1, 1 );

     insert into drop_me
    values ( 1, 2 );

     insert into drop_me
    values ( 2, 1 );

     drop table drop_me;