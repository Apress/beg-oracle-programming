create table inventory(
partno number(4) constraint invent_partno_pk primary key,
partdesc varchar2(35) constraint invent_partdesc_uq unique);

