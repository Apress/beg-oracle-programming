create table inventory(
partno number(4) constraint partno_pk primary key deferrable initially immediate,
partdesc varchar2(35) constraint partdesc_uq unique deferrable initially immediate);



