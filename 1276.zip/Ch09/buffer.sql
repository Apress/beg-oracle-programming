define _editor=vi
 -- or perhaps --
 define _editor=notepad
 clear buffer -- this command clears the contents of the SQL*Plus buffer
 edit