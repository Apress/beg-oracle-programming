accept did prompt 'Enter Department Id: ' default 10

select *
  from departments
 where department_id = &did
/

@emps.sql &did
