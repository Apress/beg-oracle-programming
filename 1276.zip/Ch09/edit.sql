select department_id, department_name
      from departmens;
 list
 change.mens.ments
 list
 input  where department_id between 10 and 40
 list
 input  order by 2
 list
 /
