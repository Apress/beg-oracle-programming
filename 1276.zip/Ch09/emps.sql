select first_name, last_name, job_id
  from employees
 where department_id = &1
/
