prompt
prompt This is a list of users and their default
prompt tablespaces

select username, default_tablespace
  from dba_users
/
