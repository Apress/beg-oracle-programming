select banner
  from v$version
/
exit
