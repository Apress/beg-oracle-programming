 declare
    l_days_in_week   constant number := 7;
    l_weeks_in_month number default 4;
  begin
    l_weeks_in_month := 5;
  end;
  /
