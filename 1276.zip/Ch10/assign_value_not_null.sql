 declare
    l_number number not null := 1;
    l_another_number number;
  begin
    l_number := 2;
    l_number := l_another_number;
  end;
  /
