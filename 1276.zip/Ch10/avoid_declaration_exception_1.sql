 declare
    l_number number;
  begin
    l_number := 'MY NUMBER';
  exception
    when OTHERS then
      dbms_output.put_line('Exception caught');
      raise;
  end;
  /
