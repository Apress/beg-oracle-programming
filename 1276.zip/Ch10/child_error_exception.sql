 declare
    CHILD_ERROR exception;
  begin
    raise CHILD_ERROR;
  end;
  /
