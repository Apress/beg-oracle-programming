 create table departments (
    department_id   number,
    department_name varchar2(30),
    manager         employee_type,
    employees       employee_list_type )
  /
