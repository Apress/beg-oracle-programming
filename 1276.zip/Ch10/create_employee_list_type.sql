 create type employee_list_type as varray(50) of employee_type
  /
