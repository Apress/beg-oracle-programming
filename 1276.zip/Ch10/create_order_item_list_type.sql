 create type order_item_list_type as table of order_item_type
  /
