 declare
    l_number number default 'MY NUMBER';
  begin
    null;
  exception
    when OTHERS then
      dbms_output.put_line('Exception caught');
      raise;
  end;
  /
