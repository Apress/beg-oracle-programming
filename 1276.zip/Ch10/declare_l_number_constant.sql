  declare
    l_number_constant  constant number := 50;
  begin
    null;
  end;
  /
