 declare
    l_number_constant constant number;
  begin
    null;
  end;
  /
