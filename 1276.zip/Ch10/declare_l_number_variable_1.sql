 declare
    l_number_variable number;
  begin
    l_number_variable := 50;
  end;
  /
