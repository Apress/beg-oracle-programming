 declare
    type refcur_t is ref cursor;
  
    type emp_refcur_t is ref cursor
      return employees%rowtype;
  begin
    null;
  end;
  /
