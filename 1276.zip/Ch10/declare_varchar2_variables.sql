 declare
    l_value1 varchar2(100);
    l_value2 varchar2(100) := '';
    l_value3 varchar2(100) := null;
    l_value4 varchar2(100) default null;
  begin
    null;
  end;
  /
