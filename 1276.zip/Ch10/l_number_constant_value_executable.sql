 declare
    l_number_constant constant number := 50;
  begin
    l_number_constant := 51;
  end;
  /
