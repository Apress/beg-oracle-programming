 declare
    l_text varchar2(100);
  begin
  end;
  /
