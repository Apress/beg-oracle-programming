 declare
    l_number number := l_another_number;
    l_another_number number := 10;
  begin
    null;
  end;
  /
