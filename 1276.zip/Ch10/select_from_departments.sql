 column department_name format a13
 column employees format a63 word_wrapped

 select department_name, employees
    from departments
  /
