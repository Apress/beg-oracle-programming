 set timing on

 declare
    some_string varchar2(255);
  begin
    for idx in 1 .. 100000 loop
      some_string := rpad('*',254,'*');
    end loop;
  end;
  /
