 set timing on

 declare
    l_idx         pls_integer := 0;
    l_some_string varchar2(255);
  begin
    loop
      l_idx := l_idx + 1;
      exit when l_idx = 100000;
      l_some_string := rpad('*',254,'*');
    end loop;
  end;
  /
