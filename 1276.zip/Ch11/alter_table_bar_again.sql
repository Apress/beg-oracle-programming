 alter table bar add d date;

 select object_type, status
    from user_objects
   where object_name = 'SHIELD'
  /
