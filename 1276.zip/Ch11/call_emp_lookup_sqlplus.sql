 variable name varchar2(10);
 variable sal number;

 exec emp_lookup( '7782', :name, :sal );

 print name

 print sal

 select :name, :sal
    from dual
  /
