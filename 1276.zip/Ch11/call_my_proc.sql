 set serverout on

 begin
    my_proc;
  end;
  /
