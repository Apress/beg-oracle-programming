create or replace
procedure out_parms( p_parm out number ) as
begin
 null;
end out_parms;
/

exec out_parms( 123 );