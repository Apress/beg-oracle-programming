 create or replace
  function bad_function return number as
  begin
    null;
  end bad_function;
  /
