create or replace
function first_function return varchar2 as
begin
  return 'Hello World';
end first_function;
/
