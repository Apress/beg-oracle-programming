create procedure marks_procedure as
begin
 null;
end;
/
