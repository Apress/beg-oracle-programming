create procedure my_proc as
begin
  null;
end my_proc;
/
