 create procedure my_proc as
  begin
    dbms_output.put_line ( 'Hello World' );
  end my_proc;
  /

