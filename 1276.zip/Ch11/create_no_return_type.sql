 create or replace
  function no_return_type as
  begin
    return null;
  end no_return_type;
  /

 show errors

