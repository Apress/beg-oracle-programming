 create table bar ( n number );

 create or replace procedure foo as
    l_n bar.n%type;
  begin
    null;
  end foo;
  /
