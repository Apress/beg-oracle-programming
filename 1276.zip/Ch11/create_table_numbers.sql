create table numbers(
  n number,
  username varchar2(30) )
/
