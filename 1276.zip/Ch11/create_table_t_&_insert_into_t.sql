 create table t(
    n number
  )
  /
	
 create or replace
  procedure insert_into_t( p_parm in number ) is
  begin
    insert into t values ( p_parm );
  end insert_into_t;
  /
