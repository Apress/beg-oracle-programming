create table log_table(
  username varchar2(30),
  date_time timestamp,
  message varchar2(4000) );

create table temp_table(
  n number );
	

