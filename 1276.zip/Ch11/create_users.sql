 create user chris identified by chris;

 grant connect, resource to chris;
	
 create user sean identified by sean;
	
 grant connect, resource to sean;
	
 create user mark identified by mark;
	
 grant connect, resource to mark;
	
	