 set serverout on

 exec default_values( 'Tom', p_parm3 => 'Joel' );
