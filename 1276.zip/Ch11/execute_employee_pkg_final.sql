 exec employee_pkg.print_ename( 7781 );

 exec employee_pkg.print_ename( 7782 );

 select * from log_table;
