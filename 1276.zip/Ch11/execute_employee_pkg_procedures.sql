 set serverout on

 execute employee_pkg.print_ename( 1234 );

 execute employee_pkg.print_ename( 7782 );

 execute employee_pkg.print_sal( 7782 );

