 select * from t;

 exec insert_into_t( p_parm => 100 );
	
 select * from t;
