 exec insert_into_t( p_parm1 => 101, p_parm2 => 102 );
	
 select * from t;
