 exec insert_into_t( p_parm1 => 200, p_parm2 => 201 );
	
 select * from t;
