 exec dbms_output.put_line( ite( 1=2, 'Equal', 'Not Equal' ) );

 exec dbms_output.put_line( ite( 2>3, 'True', 'False' ) );
