 exec variables.print_private_number;
	
 exec dbms_output.put_line( nvl( to_char(variables.g_public_number), 'null' ) );

