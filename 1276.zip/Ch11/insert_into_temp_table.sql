select * from temp_table;

select * from log_table;

begin
 log_message( 'About to insert into temp_table' );
 insert into temp_table( n )
 values( 12345 );
 log_message( 'rolling back insert into temp_table' );
 rollback;
end;
/

select * from temp_table

select * from log_table