 select object_name, object_type
    from user_objects
   where object_type in ( 'PROCEDURE', 'FUNCTION',
                          'PACKAGE', 'PACKAGE BODY' );
