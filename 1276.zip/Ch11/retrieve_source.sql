 desc user_source

 select text
    from user_source
   where name = 'LOG_MESSAGE'
     and type = 'PROCEDURE'
   order by line;
