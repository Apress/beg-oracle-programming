 select to_char( sysdate, 'HH24:MI:SS' ) "DATE" from dual;
	
 select to_char( 111, '099.99' ) "NUMBER" from dual;
