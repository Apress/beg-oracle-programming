 select object_name, status
    from user_objects
   where object_type = 'PROCEDURE';
