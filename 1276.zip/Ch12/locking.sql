create table a as select 1 x from dual;
create table b as select 1 x from dual;
 update a set x = x+1; ---(session1)
 update b set x = x+1; ---(session2)
 update a set x = x+1; ---(session2)

