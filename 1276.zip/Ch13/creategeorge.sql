connect scott/tiger
 create user george identified by jetson;
 connect system/manager
create user george identified by jetson;