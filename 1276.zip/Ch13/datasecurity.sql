 select my_encrypt('MyData', 'thekey') from dual;
select rawtohex(my_encrypt('MyData', 'thekey')) from dual;
select my_decrypt( utl_raw.cast_to_varchar2(hextoraw('128C3F40EAB51FF2')), 'thekey')
      from dual
    /
set serveroutput on
    declare
        l_md varchar2(16);
    begin
        l_md := dbms_obfuscation_toolkit.md5(
            input_string => '911' );
        dbms_output.put_line( 'MD5 of 911: ' ||
            utl_raw.cast_to_raw( l_md ));
        --
        l_md := dbms_obfuscation_toolkit.md5(
           input_string => '411' );
       dbms_output.put_line( 'MD5 of 411: ' ||
           utl_raw.cast_to_raw( l_md ));
  end;
 /

