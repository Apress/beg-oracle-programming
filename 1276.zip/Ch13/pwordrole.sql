--connect george/jetson
alter role assembly_line identified by robot;
--connect scott/tiger
insert into george.sprockets values( 5, 'Carbon', 60 );
set role assembly_line identified by robot;
 insert into george.sprockets values( 5, 'Carbon', 60 );