--connect george/jetson
desc user_tab_privs;
 grant all on mytable to scott;
select * from user_tab_privs;