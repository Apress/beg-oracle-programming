 Alter table t
  modify
  (
   id number,
   data varchar2(255)
  );

 Alter table t
  ADD
  (
   data2 varchar2(100)
  );

 desc t