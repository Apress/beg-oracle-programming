 create view department_10 as
    select *
      from employees
     where department_id = 10
      with check option;
