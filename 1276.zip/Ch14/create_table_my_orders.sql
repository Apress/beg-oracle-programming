 create table my_orders as
    select *
     from orders;
