 create table t(
    id number,
    data varchar2(200) );
