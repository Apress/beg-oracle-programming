 create view view_t as
    select id view_id, data view_data
      from t;
