 drop table t;

 select *
    from view_t;
