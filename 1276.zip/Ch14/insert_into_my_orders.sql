 insert into my_orders
    select *
      from my_orders;

 /

 /

 /

 /

 /

 /

 /

 /

 /

 select count(*)
    from my_orders;
