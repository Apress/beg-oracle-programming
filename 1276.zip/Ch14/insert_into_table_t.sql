 insert into t
  values ( 1, 'ACB' );

 select *
    from view_t;
