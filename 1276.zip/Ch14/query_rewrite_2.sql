 alter session set query_rewrite_enabled=true;

 select customer_id,
         count(*) total_orders
    from my_orders
   group by customer_id;
