 set autotrace on
 select count(*)
    from my_orders;
