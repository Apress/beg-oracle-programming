 select employee_id, first_name, last_name
    from department_10;
