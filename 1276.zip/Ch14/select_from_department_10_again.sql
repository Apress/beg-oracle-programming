 select employee_id, last_name, first_name, salary
    from department_10
   where manager_id = 101;
