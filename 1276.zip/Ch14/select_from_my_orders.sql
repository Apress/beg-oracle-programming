 set autotrace on
 set timing on
 select customer_id,
         count(*) total_orders
    from my_orders
    group by customer_id
  /
