 select *
    from user_updatable_columns
   where table_name = 'COMPANY_PHONE_BOOK';
