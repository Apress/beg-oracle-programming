 select VIEW_TYPE_OWNER, VIEW_TYPE, OID_TEXT
    from user_views
   where view_name = 'OV_COMPANY_PHONE_BOOK'
  /
