 select *
    from view_t;
