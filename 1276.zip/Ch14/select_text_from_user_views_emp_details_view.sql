 set long 5000

 select text
    from user_views
   where view_name = 'EMP_DETAILS_VIEW';
