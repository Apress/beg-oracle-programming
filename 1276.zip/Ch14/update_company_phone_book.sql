 update company_phone_book
     set email = 'CLBECK'
   where emp_id = 100;

 update company_phone_book
     set name = 'Beck, Christopher'
   where emp_id = 100;
