 select *
    from company_phone_book
   where emp_id = 100;

 update company_phone_book
     set name = 'Beck, Christopher'
    where emp_id = 100;


 select *
    from company_phone_book
   where emp_id = 100;
