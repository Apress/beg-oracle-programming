 update department_10
 set department_id = 20
 where employee_id = 200;
