create trigger bi_foo
  before insert
     on foo
begin
  null  -- missing ";"
end;
/
