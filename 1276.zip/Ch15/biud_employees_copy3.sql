create or replace trigger biud_employees_copy
  before insert or update or delete
     on employees_copy
begin
  null;
end;
/
