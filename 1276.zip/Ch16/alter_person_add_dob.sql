alter type person
add attribute dob date
cascade not including table data
/
