 create table address_table of address
  /
