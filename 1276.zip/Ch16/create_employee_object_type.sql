create or replace
type employee as object(
 name person,
 empno number,
 hiredate date )
/
