create table employees (e employee )
/
