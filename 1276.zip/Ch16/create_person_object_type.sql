create or replace
type person as object(
 first_name varchar2(100),
 last_name varchar2(100) )
/
