create table person_table(
 name person,
 age number )
/
