 delete from address_table
   where id = 1
  /
