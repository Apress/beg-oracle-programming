 create or replace
  type super_type as object(
    n number
  )
  final
  /

 create or replace
  type sub_type
  under super_type(
    v varchar2(200)
  )
  /

 show error
