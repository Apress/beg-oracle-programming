insert into address_table
values ( address( 2, '123 Main Street', 'NJ', '07728' ) )
/
