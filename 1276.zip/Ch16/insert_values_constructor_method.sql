insert into person_table
values ( person( 'Sean', 'Dillon' ), 30 );
