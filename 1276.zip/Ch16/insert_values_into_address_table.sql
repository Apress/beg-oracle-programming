insert into address_table
values ( 1, '1910 Oracle Way', 'VA', '21090' )
/
