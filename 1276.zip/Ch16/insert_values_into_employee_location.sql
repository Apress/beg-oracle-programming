insert into employee_location
select 12345, ref(a)
   from address_table a
 where id = 1
/


insert into employee_location
select 67890, ref(a)
   from address_table a
 where id = 2
/


insert into employee_location
select 24680, ref(a)
   from address_table a
 where id = 1
/


