insert into new_person_table values
( new_person( null, 'Kyte', null, '703.555.5555' ) )
/

insert into new_person_table values
( new_employee(  null, 'Beck', null, '703.555.1111', 1234, null, '703.555.2222' ) )
/

insert into new_person_table values
( new_employee(  null, 'Dillon', null, '703.555.3333', 5678, null, '703.555.4444' ) )
/
