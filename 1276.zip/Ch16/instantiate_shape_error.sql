declare
 l_shape shape;
begin
 l_shape := shape( 2 );
end;
/


