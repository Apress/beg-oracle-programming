select treat( x.p as new_employee ).empno empno,
       x.p.last_name last_name
   from new_person_table x
  where p is of ( new_employee )
/
