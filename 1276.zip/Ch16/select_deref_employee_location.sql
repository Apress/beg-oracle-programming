select empno,
       deref(loc_ref)
  from employee_location
/
