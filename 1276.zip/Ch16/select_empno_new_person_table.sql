 select x.p.empno
    from new_person_table p
  /
