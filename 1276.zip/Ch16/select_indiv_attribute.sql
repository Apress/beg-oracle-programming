select p.name.first_name
 from person_table p
/
