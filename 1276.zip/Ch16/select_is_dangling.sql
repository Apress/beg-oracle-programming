select empno
 from employee_location
where loc_ref is dangling
/
