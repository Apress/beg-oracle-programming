 select x.p.last_name
    from new_person_table x
  /
