select value(a)
 from address_table a
/
