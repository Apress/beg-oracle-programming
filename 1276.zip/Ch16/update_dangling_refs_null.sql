update employee_location
 set loc_ref = null
where loc_ref is dangling;
