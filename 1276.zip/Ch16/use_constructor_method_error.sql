declare
 l_person person;
begin
 l_person := person( 'sean');
 dbms_output.put_line( l_person.first_name );
end;
/
