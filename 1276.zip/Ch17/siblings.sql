select lpad( ' ', (level-1)*2, ' ' ) || ename ename
       from emp
      start with mgr is null
    connect by prior empno = mgr
      order by ename;
select lpad( ' ', (level-1)*2, ' ' ) || ename ename
       from emp
      start with mgr is null
    connect by prior empno = mgr
      order siblings by ename;
