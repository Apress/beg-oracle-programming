 create table t ( x int );
 begin
        for i in 1 .. 100
        loop
            execute immediate 'insert into t values ( ' || i || ')';
        end loop;
    end;
    /
     create or replace
    function remove_constants( p_query in varchar2 )
    return varchar2
    as
        l_query long;
        l_char  varchar2(1);
        l_in_quotes boolean default FALSE;
    begin
        for i in 1 .. length( p_query )
       loop
           l_char := substr(p_query,i,1);
           if ( l_char = '''' and l_in_quotes )
           then
               l_in_quotes := FALSE;
           elsif ( l_char = '''' and NOT l_in_quotes )
           then
               l_in_quotes := TRUE;
               l_query := l_query || '''#';
           end if;
           if ( NOT l_in_quotes ) then
               l_query := l_query || l_char;
           end if;
       end loop;
       l_query := translate( l_query, '0123456789', '@@@@@@@@@@' );
       for i in 0 .. 8 loop
           l_query := replace( l_query, lpad('@',10-i,'@'), '@' );
           l_query := replace( l_query, lpad(' ',10-i,' '), ' ' );
       end loop;
       return upper (l_query);
   end;
   /

    create global temporary table sql_area_tmp
    on commit preserve rows
    as
    select sql_text, sql_text sql_text_wo_constants
      from v$sqlarea
     where 1=0
    /
 insert into sql_area_tmp (sql_text)
    select sql_text from v$sqlarea
    /
     update sql_area_tmp
       set sql_text_wo_constants = remove_constants(sql_text)
    /
     select sql_text_wo_constants, count(*)
      from sql_area_tmp
     group by sql_text_wo_constants
    having count(*) > 10
     order by 2
   /
