set autotrace on

     SELECT ename,dname
      FROM emp  inner join dept
        ON ( emp.deptno = dept.deptno )
    /