 set autotrace traceonly

 alter session set optimizer_goal=rule;

     SELECT ename,dname
      FROM emp  inner join dept
        ON ( emp.deptno = dept.deptno )
    /
