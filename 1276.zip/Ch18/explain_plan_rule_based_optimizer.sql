alter session set optimizer_goal = rule;

    EXPLAIN PLAN
    SET STATEMENT_ID = 'example' FOR
    SELECT ename,dname
    FROM emp  inner join dept
    ON ( emp.deptno = dept.deptno )
    /

  @%ORACLE_HOME%\rdbms\admin\utlxpls.sql